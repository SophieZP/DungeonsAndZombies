import greenfoot.*;

public class Arma extends Item {
    public Arma() {
        // Establecer imagen para el arma
        //setImage("arma.png"); // Coloca la imagen correspondiente en el proyecto
    }
    
    public void act(){
        // Aquí puedes programar el comportamiento al ser recogida o usada.
    }
}