import greenfoot.*;

public class Item extends Actor {
    public void act() {
        // Comportamiento por defecto de los ítems (puedes expandirlo)
    }
}
